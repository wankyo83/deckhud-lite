# DeckHUD Lite

DeckHUD Lite는 최신 Decky Loader API를 사용하는 작은 SteamOS HUD 플러그인입니다. Steam의 MangoApp 설정을 감지해 다음 정보를 원하는 모양으로 표시합니다.

- 배터리 잔량(%)
- 현재 소비전력(W)
- 현재 소비량 기준 예상 남은 시간
- 현재 시각
- 선택 사항: FPS
- 수평(한 줄)·수직(여러 줄) 방향 전환
- 표시 블록 순서 변경
- 항목 사이 구분선과 색상 선택
- 선택 사항: 팬 RPM, 화면 주사율, 설정된 FPS 제한

수평 HUD는 켜진 그룹 사이에만 선택한 구분자를 넣습니다. 시각은 `TIME 09:20`처럼 표시해 배터리 예상 시간과 구별하며, 배터리 잔량·소비전력·예상 시간은 하나의 배터리 항목으로 켜고 끕니다.

## 설치

1. Steam Deck의 Decky Loader 설정에서 `Developer Mode`를 켭니다.
2. 릴리스 ZIP을 Deck으로 복사합니다.
3. Decky 설정의 `Install Plugin from ZIP File`에서 ZIP을 선택합니다.
4. 게임을 실행하고 Steam 성능 오버레이 레벨을 1 이상으로 설정합니다.
5. `…` 버튼 → Decky → DeckHUD Lite에서 원하는 항목을 설정합니다.

게임이 실행되지 않았을 때는 `게임 실행을 기다리는 중`이 정상입니다. 게임을 시작하면 약 2초 안에 자동 적용됩니다.

배터리 잔량·소비전력·남은 시간은 SteamOS의 MangoHud가 하나의 배터리 블록으로 제공하므로 블록 안에서는 이 순서로 표시됩니다. 배터리 블록 전체와 시각, FPS, 팬 속도, 주사율, FPS 제한 블록의 순서는 자유롭게 변경할 수 있습니다.

## 안전한 복구

처음 HUD를 바꾸기 전에 원래 MangoApp 설정을 플러그인 설정 폴더에 백업합니다. `원래 Steam HUD로 복원`을 누르거나 플러그인을 제거하면 가능한 경우 백업을 되돌립니다.

## 개발 빌드

Node.js 16.14 이상과 pnpm 9가 필요합니다.

```sh
pnpm install
pnpm run typecheck
pnpm run build
```

배포 ZIP은 `scripts/package.ps1`로 만들며, 생성 직후 최신 Decky 개발자 ZIP 구조를 자동 검증합니다.

## 알려진 제한

- Steam 성능 오버레이가 완전히 꺼져 있으면 MangoApp 프로세스가 없어 HUD를 표시할 수 없습니다.
- 남은 시간은 현재 소비전력에 따른 MangoHud 추정값이므로 부하가 급변하면 값도 크게 바뀔 수 있습니다.
- 실제 Steam Deck/SteamOS 검증 전의 초기 버전입니다.

## License

MIT
